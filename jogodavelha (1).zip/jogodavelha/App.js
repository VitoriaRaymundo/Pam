import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image, Alert, ImageBackground } from 'react-native';
 
const emptyBoard = Array(9).fill(null);
 
export default function App() {
  const [started, setStarted] = useState(false);
  const [board, setBoard] = useState(emptyBoard);
  const [isXTurn, setIsXTurn] = useState(true);
  const [winner, setWinner] = useState(null);
  const [gameMode, setGameMode] = useState(null);
 
  const xImg = require('./assets/x.png');
  const oImg = require('./assets/o.png');
  const backgroundImg = require('./assets/background.jpg');
 
  const checkWinner = (newBoard) => {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    for (let [a, b, c] of lines) {
      if (newBoard[a] && newBoard[a] === newBoard[b] && newBoard[a] === newBoard[c]) {
        return newBoard[a];
      }
    }
    if (!newBoard.includes(null)) return 'draw';
    return null;
  };
 
  const handlePress = (index) => {
    if (board[index] || winner) return;
 
    const newBoard = [...board];
    newBoard[index] = isXTurn ? 'X' : 'O';
    const result = checkWinner(newBoard);
 
    setBoard(newBoard);
    setIsXTurn(!isXTurn);
 
    if (result) {
      setWinner(result);
      Alert.alert(
        result === 'draw' ? 'Empate!' : `Vencedor: ${result}`,
        '',
        [{ text: 'Reiniciar', onPress: resetGame }]
      );
    }
  };
 
  const resetGame = () => {
    setBoard(emptyBoard);
    setIsXTurn(true);
    setWinner(null);
  };
 
  const renderCell = (value, index) => (
    <TouchableOpacity
      key={index}
      style={styles.cell}
      onPress={() => handlePress(index)}
    >
      {value && (
        <Image
          source={value === 'X' ? xImg : oImg}
          style={styles.symbol}
          resizeMode="contain"
        />
      )}
    </TouchableOpacity>
  );
 
  const startGame = (mode) => {
    setGameMode(mode);
    setStarted(true);
  };
 
  const computerMove = () => {
    const emptyIndexes = board.map((value, index) => value === null ? index : null).filter(index => index !== null);
    const randomIndex = emptyIndexes[Math.floor(Math.random() * emptyIndexes.length)];
    handlePress(randomIndex);
  };
 
  if (gameMode === 'computer' && !isXTurn && !winner) {
    setTimeout(() => computerMove(), 500);
  }
 
  if (!started) {
    return (
      <ImageBackground source={backgroundImg} style={styles.container}>
        <Text style={styles.title}>Jogo da Velha</Text>
        <TouchableOpacity style={styles.startButton} onPress={() => startGame('duo')}>
          <Text style={styles.startButtonText}>Jogar em Dupla</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.startButton} onPress={() => startGame('computer')}>
          <Text style={styles.startButtonText}>Jogar contra computador</Text>
        </TouchableOpacity>
      </ImageBackground>
    );
  }
 
  return (
    <ImageBackground source={backgroundImg} style={styles.container}>
      <Text style={styles.title}>Jogo da Velha</Text>
      <View style={styles.board}>
        {board.map((cell, index) => renderCell(cell, index))}
      </View>
      <TouchableOpacity style={styles.startButton} onPress={resetGame}>
        <Text style={styles.startButtonText}>Reiniciar</Text>
      </TouchableOpacity>
    </ImageBackground>
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#add8e6',
 
    textShadowColor: '#000',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 3,
 
  },
  board: {
    width: 300,
    height: 300,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  cell: {
    width: 100,
    height: 100,
    borderWidth: 1,
    borderColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  symbol: {
    width: 60,
    height: 60,
  },
  startButton: {
    marginTop: 20,
    padding: 15,
    backgroundColor: '#add8e6',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    height: 50,
  },
  startButtonText: {
    color: '#ddfada',
    fontSize: 18,
    fontWeight: 'bold'
  },
});
 
 